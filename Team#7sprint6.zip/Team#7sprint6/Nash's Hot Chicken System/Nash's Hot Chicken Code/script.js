let cart = [];

function loadMenu() {
    const menuContainer = document.getElementById("menu");
    menuContainer.innerHTML = "";

    for (let category in menu) {
        let categoryHeader = document.createElement("h2");
        categoryHeader.textContent = category;
        menuContainer.appendChild(categoryHeader);

        menu[category].forEach(item => {
            let itemContainer = document.createElement("div");
            itemContainer.classList.add("menu-item");
        
            let itemDetails = document.createElement("div");
            itemDetails.classList.add("item-details");
        
            let itemName = document.createElement("div");
            itemName.classList.add("item-name");
            itemName.textContent = item.name;
        
            let itemDescription = document.createElement("div");
            itemDescription.textContent = item.description || "";
        
            itemDetails.appendChild(itemName);
            itemDetails.appendChild(itemDescription);
        
            let rightContainer = document.createElement("div");
            rightContainer.classList.add("right-container");
        
            let itemPrice = document.createElement("div");
            itemPrice.classList.add("item-price");
            itemPrice.textContent = `$${item.price.toFixed(2)}`;

            let qtyInput = document.createElement("input");
            qtyInput.type = "number";
            qtyInput.min = "1";
            qtyInput.value = "1";
            qtyInput.classList.add("quantity-input");
        
            // ✅ Add to Cart Button w/ Confirmation
            let addButton = document.createElement("button");
            addButton.classList.add("add-to-cart");
            addButton.textContent = "Add to Cart";
        
            addButton.onclick = () => {
                const quantity = parseInt(qtyInput.value) || 1;
                for (let i = 0; i < quantity; i++) {
                    addToCart(item.name, item.price);
                }
            
                // Visual confirmation
                addButton.textContent = "✔️ Added!";
                addButton.disabled = true;
                addButton.classList.add("added");
            
                setTimeout(() => {
                    addButton.textContent = "Add to Cart";
                    addButton.disabled = false;
                    addButton.classList.remove("added");
                }, 1200);
        
                // Visual confirmation
                addButton.textContent = "✔️ Added!";
                addButton.disabled = true;
                addButton.classList.add("added");
        
                setTimeout(() => {
                    addButton.textContent = "Add to Cart";
                    addButton.disabled = false;
                    addButton.classList.remove("added");
                }, 1200);
            };
        
            rightContainer.appendChild(itemPrice);
            rightContainer.appendChild(qtyInput);
            rightContainer.appendChild(addButton);
        
            itemContainer.appendChild(itemDetails);
            itemContainer.appendChild(rightContainer);
        
            menuContainer.appendChild(itemContainer);
        });
    }
}


function addToCart(itemName, itemPrice) {
    // Check if item already exists
    const existing = cart.find(item => item.item === itemName);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ item: itemName, price: itemPrice, quantity: 1 });
    }
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    let total = 0;

    cart.forEach((order, index) => {
        const itemTotal = order.price * order.quantity;
        total += itemTotal;

        const listItem = document.createElement("li");
        listItem.innerHTML = `
            ${order.item} (x${order.quantity}) - $${itemTotal.toFixed(2)}
            <button class="qty-btn" data-index="${index}" data-action="decrease">−</button>
            <button class="qty-btn" data-index="${index}" data-action="increase">+</button>
            <button class="remove-item" data-index="${index}">Remove</button>
        `;
        cartList.appendChild(listItem);
    });

    const totalItem = document.createElement("li");
    totalItem.textContent = `Total: $${total.toFixed(2)}`;
    cartList.appendChild(totalItem);

    // Handle quantity and remove buttons
    document.querySelectorAll(".qty-btn").forEach(btn => {
        btn.addEventListener("click", function () {
            const index = parseInt(this.getAttribute("data-index"));
            const action = this.getAttribute("data-action");
            if (action === "increase") {
                cart[index].quantity += 1;
            } else if (action === "decrease") {
                cart[index].quantity -= 1;
                if (cart[index].quantity <= 0) {
                    cart.splice(index, 1);
                }
            }
            updateCart();
        });
    });

    document.querySelectorAll(".remove-item").forEach(btn => {
        btn.addEventListener("click", function () {
            const index = parseInt(this.getAttribute("data-index"));
            cart.splice(index, 1);
            updateCart();
        });
    });
}

document.getElementById("orderForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const pickupTime = document.getElementById("pickup-time").value;

    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    const orderData = {
        name,
        phone,
        pickupTime,
        cart
    };

    // Save to localStorage so we can access it on confirm.html
    localStorage.setItem("orderData", JSON.stringify(orderData));

    // Redirect to confirmation screen
    window.location.href = "checkout.html";
});

window.onload = loadMenu;
