const menu = {
    "Opening Acts": [
        { name: "Grand Ole Slopry Hot Fries", description: "Seasoned hand-cut fries smothered with queso, topped with diced pickles and your choice of heat.", price: 10 },
        { name: "Roasted Street Corn Dip", description: "Roasted street corn dip served with fresh fried tortilla points.", price: 11 },
        { name: "Fried Picks", description: "Fried pickles served with our signature Rooster Sauce for dunking.", price: 11 },
        { name: "Fried Okra", description: "Fried okra served with our signature Rooster Sauce for dunking.", price: 11 },
        { name: "Riverboat Nachos", description: "Fresh tortilla chips smothered in queso, pico, black beans, and jalapeños. Add chicken +3", price: 11 },
        { name: "Mozz Balls", description: "Fried mozzarella balls tossed in sauce of your choice.", price: 10 }
    ],
    "Headliners": [
        { name: "The Nash", description: "Two chicken tenders tucked between thick slices of buttered Texas toast, topped with classic pickle chips and our signature Rooster sauce.", price: 15 },
        { name: "Tendies", description: "Two colossal hand-breaded, juicy, hot chicken tenders. Add additional tender +$3", price: 13 },
        { name: "Cluck-fast", description: "Two chicken tenders atop a fresh made Belgian waffle, drizzled with syrup and hot honey.", price: 15 },
        { name: "Nash-a-dilla", description: "Signature Nash Hot Chicken with melted pepper jack cheese in a toasted tortilla. Add mac +2", price: 13 },
        { name: "The Ryman Wrap", description: "A fried or grilled tendie mixed with slaw, fresh lettuce, tomato, onion, shredded cheese, snuggled tight in a spinach wrap.", price: 13 },
        { name: "The Loretta", description: "Traditional turkey or veggie burger on buttered Texas toast, lettuce, tomato, onion, and pickle.", price: 14 },
        { name: "Broadway Basket", description: "Six hand-breaded, juicy, jumbo wings. Add additional wing +1", price: 15 },
        { name: "The Impeckable Chicken Cheesesteak", description: "Two chicken tenders chopped with peppers, onion, and pepper jack cheese on a toasted hoagie. Also available grilled.", price: 16 },
        { name: "Wrangler Wrap", description: "A fried or grilled tendie, cheese, bacon, Rooster Sauce, lettuce, tomato, and cucumber.", price: 15 }
    ],
    "Salads & Such": [
        { name: "House Salad", description: "Freshly chopped lettuce, tomato, onion, cucumber, and cheese. Try it topped with our Hot Chicken +$3", price: 9 },
        { name: "Blue Bird Boat", description: "A fresh lettuce boat with blue cheese crumbles, diced tomatoes, and our signature Nash Hot Chicken. Also available grilled.", price: 12 },
        { name: "Nash Chili", description: "A traditional white chicken chili with a Nash kick. Topped with fresh fried tortilla straws and sour cream.", price: 9 }
    ],
    "Sides": [
        { name: "Mac & Cheese", price: 4 },
        { name: "Baked Beans", price: 3 },
        { name: "Slaw", price: 3 },
        { name: "Street Corn", price: 4 },
        { name: "Hand Cut Fries", price: 4 },
        { name: "Pasta Salad", price: 4 },
        { name: "Green Beans", price: 3 },
        { name: "Collards", price: 4 },
        { name: "Fried Okra", price: 4 },
        { name: "Potato Salad", price: 4 },
        { name: "Fried Pickles", price: 4 }
    ],
    "Kids": [
        { name: "Grilled Cheese", price: 5 },
        { name: "Mac & Cheese", price: 5 },
        { name: "Chicken Nuggies", price: 5 }
    ],
    "Desserts": [
        { name: "Banana Pudding", price: 5 },
        { name: "Dirt Cake", price: 5 },
        { name: "Waffle Churros", price: 5 }
    ],
};
