let cart = [];

function loadMenu() {
    const menuContainer = document.getElementById("menu");
    menuContainer.innerHTML = "";

    for (let category in menu) {
        let categoryHeader = document.createElement("h2");
        categoryHeader.textContent = category;
        menuContainer.appendChild(categoryHeader);

        menu[category].forEach(item => {
            let itemContainer = document.createElement("div");
            itemContainer.classList.add("menu-item");

            // Left side: Name + Description
            let itemDetails = document.createElement("div");
            itemDetails.classList.add("item-details");

            let itemName = document.createElement("div");
            itemName.classList.add("item-name");
            itemName.textContent = item.name;

            let itemDescription = document.createElement("div");
            itemDescription.textContent = item.description || "";

            itemDetails.appendChild(itemName);
            itemDetails.appendChild(itemDescription);

            // Right side: Price + Button container
            let rightContainer = document.createElement("div");
            rightContainer.classList.add("right-container");

            let itemPrice = document.createElement("div");
            itemPrice.classList.add("item-price");
            itemPrice.textContent = `$${item.price.toFixed(2)}`;

            let addButton = document.createElement("button");
            addButton.classList.add("add-to-cart");
            addButton.textContent = "Add to Cart";
            addButton.onclick = () => addToCart(item.name, item.price);

            rightContainer.appendChild(itemPrice);
            rightContainer.appendChild(addButton);

            itemContainer.appendChild(itemDetails);
            itemContainer.appendChild(rightContainer);

            menuContainer.appendChild(itemContainer);
        });
    }
}


function addToCart(item, price) {
    cart.push({ item, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    let total = 0;

    cart.forEach(order => {
        let listItem = document.createElement("li");
        listItem.textContent = `${order.item} - $${order.price.toFixed(2)}`;
        cartList.appendChild(listItem);
        total += order.price;
    });

    let totalItem = document.createElement("li");
    totalItem.textContent = `Total: $${total.toFixed(2)}`;
    cartList.appendChild(totalItem);
}

document.getElementById("orderForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const pickupTime = document.getElementById("pickup-time").value;

    alert(`Thanks, ${name}! Your order will be ready at ${pickupTime}.`);
    cart = [];
    updateCart();
});

window.onload = loadMenu;
